"""Generate new PDP images with Higgsfield Cloud, using the competitor images as references.

Uses the official `higgsfield-client` SDK (https://cloud.higgsfield.ai). Credentials in .env:
    HF_KEY=<api-key>:<api-secret>        (or HF_API_KEY + HF_API_SECRET)

The model and the argument that carries reference URLs are configurable because Higgsfield
exposes many models (Seedream edit, Soul, Nano Banana, ...) with slightly different argument
names. Defaults: HIGGSFIELD_MODEL=openai/gpt-image-2/edit, HIGGSFIELD_IMAGE_ARG=image_urls.
Check the model card on cloud.higgsfield.ai and change .env if yours differs.

Output goes to <product dir>/<product name>_shopify_PDP_imgs/ with a generation log.
"""
from __future__ import annotations

import json
import logging
import re
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

from . import config

log = logging.getLogger("pdpkit.higgsfield")

IMAGE_SUFFIXES = (".jpg", ".jpeg", ".png", ".webp")


def pick_references(competitor_dir: Path, max_refs: int | None = None, prefer: str = "gallery") -> list[Path]:
    """Reference images in a stable order: gallery photos first, then page images."""
    max_refs = max_refs or config.HIGGSFIELD_MAX_REFS
    files = sorted(p for p in competitor_dir.iterdir() if p.suffix.lower() in IMAGE_SUFFIXES)
    gallery = [p for p in files if p.name.startswith("gallery_")]
    page = [p for p in files if not p.name.startswith("gallery_")]
    ordered = gallery + page if prefer == "gallery" else page + gallery
    return ordered[:max_refs]


class UploadError(RuntimeError):
    pass


def _put_exact(url: str, data: bytes, headers: dict) -> requests.Response:
    """PUT to a pre-signed URL without letting requests re-quote the query string:
    the signature covers the URL byte for byte."""
    session = requests.Session()
    prep = requests.Request("PUT", "https://placeholder.invalid/", data=data, headers=headers).prepare()
    prep.url = url
    return session.send(prep, timeout=(10, 180))


def request_upload_url(client, content_type: str) -> tuple[str, str, dict]:
    """POST /files/generate-upload-url. Returns (public_url, upload_url, extra headers to send).
    Higgsfield may sign the upload URL for headers beyond Content-Type (seen: x-amz-tagging);
    any header-like field in the response is forwarded to the PUT."""
    from higgsfield_client.http.error import raise_for_status

    resp = client._transport.request("POST", "/files/generate-upload-url", json={"content_type": content_type})
    raise_for_status(resp)
    body = resp.json()
    log.debug("generate-upload-url response: %s", json.dumps({k: (v[:120] + "..." if isinstance(v, str) and len(v) > 120 else v) for k, v in body.items()}))
    extra: dict = {}
    for key in ("headers", "upload_headers", "required_headers"):
        if isinstance(body.get(key), dict):
            extra.update({str(k): str(v) for k, v in body[key].items()})
    for key in ("x-amz-tagging", "tagging", "tags", "x_amz_tagging"):
        val = body.get(key)
        if isinstance(val, str):
            extra["x-amz-tagging"] = val
        elif isinstance(val, dict):
            from urllib.parse import urlencode
            extra["x-amz-tagging"] = urlencode(val)
    return body["public_url"], body["upload_url"], extra


def _signed_headers(upload_url: str) -> list[str]:
    from urllib.parse import parse_qs, urlparse
    q = parse_qs(urlparse(upload_url).query)
    return q.get("X-Amz-SignedHeaders", [""])[0].split(";") if q.get("X-Amz-SignedHeaders") else []


def upload_bytes(client, data: bytes, content_type: str) -> str:
    """Ask Higgsfield for a pre-signed upload URL, then PUT the bytes to it.
    Tries the header shapes buckets are commonly signed for; raises UploadError with the
    bucket's full answer (it names the signed headers) when every shape is refused."""
    public_url, upload_url, extra = request_upload_url(client, content_type)
    log.debug("upload url host=%s query=%s", upload_url.split("/")[2], upload_url.split("?", 1)[-1][:300])
    signed = _signed_headers(upload_url)
    log.debug("signed headers: %s; extra headers from Higgsfield: %s", signed, extra)
    base = {"Content-Type": content_type, **extra}
    attempts = [
        ("Content-Type + Higgsfield headers", base),
        ("Content-Type only", {"Content-Type": content_type}),
        ("no Content-Type", {}),
    ]
    if "x-amz-tagging" in signed and "x-amz-tagging" not in {k.lower() for k in base}:
        # the URL was signed for a tagging header we were not told about: try the usual values
        for tag in ("", "ttl=1d", "expires=1d", "type=input"):
            attempts.insert(1, (f"x-amz-tagging={tag!r}", {**base, "x-amz-tagging": tag}))
    failures = []
    for label, headers in attempts:
        r = _put_exact(upload_url, data, headers)
        if 200 <= r.status_code < 300:
            log.debug("upload accepted with %s", label)
            return public_url
        failures.append(f"[{label}] HTTP {r.status_code}: {r.text[:400]}")
        if r.status_code not in (400, 403):
            break
    raise UploadError(f"pre-signed upload refused by the storage bucket (URL signed for headers {signed}; "
                      f"Higgsfield supplied {extra or 'none'}):\n" + "\n".join(failures))


def upload_references(client, refs: list[Path]) -> list[str]:
    urls = []
    for p in refs:
        import mimetypes
        ctype = mimetypes.guess_type(p.name)[0] or "image/jpeg"
        url = upload_bytes(client, p.read_bytes(), ctype)
        log.info("uploaded %s -> %s", p.name, url)
        urls.append(url)
    return urls


# Request shapes verified with `hf-fields` (the validator names the fields it knows). Models not listed
# get the generic shape. "per_call" = images one request returns; generate() repeats the request otherwise.
MODEL_PROFILES = {
    "openai/gpt-image-2/edit": {"fields": ("prompt", "image_urls", "quality"), "per_call": 1},
    "openai/gpt-image-1.5/edit": {"fields": ("prompt", "image_urls", "quality"), "per_call": 1},
}
GENERIC_PROFILE = {"fields": ("prompt", "image_arg", "aspect_ratio", "resolution", "num_images"), "per_call": None}


def profile_for(model: str) -> dict:
    return MODEL_PROFILES.get(model, GENERIC_PROFILE)


def build_arguments(prompt: str, ref_urls: list[str], *, num_images: int | None = None, model: str | None = None) -> dict:
    model = model or config.HIGGSFIELD_MODEL
    fields = profile_for(model)["fields"]
    candidates = {
        "prompt": prompt,
        "image_arg": (config.HIGGSFIELD_IMAGE_ARG, ref_urls),
        "image_urls": ("image_urls", ref_urls),
        "quality": config.HIGGSFIELD_QUALITY,
        "aspect_ratio": config.HIGGSFIELD_ASPECT,
        "resolution": config.HIGGSFIELD_RESOLUTION,
        "num_images": num_images or config.HIGGSFIELD_NUM_IMAGES,
    }
    args = {}
    for f in fields:
        v = candidates[f]
        if isinstance(v, tuple):
            args[v[0]] = v[1]
        else:
            args[f] = v
    if config.HIGGSFIELD_EXTRA_ARGS:
        try:
            args.update(json.loads(config.HIGGSFIELD_EXTRA_ARGS))
        except ValueError:
            log.warning("HIGGSFIELD_EXTRA_ARGS is not valid JSON; ignored")
    return args


def result_image_urls(result: dict) -> list[str]:
    """Higgsfield results carry images under 'images' (list of {url}) or a single 'image'."""
    out = []
    for key in ("images", "output", "results"):
        items = result.get(key)
        if isinstance(items, list):
            for it in items:
                if isinstance(it, dict) and it.get("url"):
                    out.append(it["url"])
                elif isinstance(it, str) and it.startswith("http"):
                    out.append(it)
    single = result.get("image")
    if isinstance(single, dict) and single.get("url"):
        out.append(single["url"])
    elif isinstance(single, str):
        out.append(single)
    return list(dict.fromkeys(out))


def download(url: str, dest: Path) -> Path:
    r = requests.get(url, timeout=config.REQUEST_TIMEOUT)
    r.raise_for_status()
    ctype = r.headers.get("content-type", "").lower()
    ext = ".png" if "png" in ctype else ".webp" if "webp" in ctype else ".jpg"
    if dest.suffix.lower() not in IMAGE_SUFFIXES:
        dest = dest.with_suffix(ext)
    dest.write_bytes(r.content)
    return dest


def generate(product_dir: Path, product_name: str, prompts: list[str], *, refs: list[Path] | None = None,
             num_images: int | None = None, model: str | None = None, dry_run: bool = False) -> Path:
    """Run every prompt against the same references; save all images to the output folder.
    Returns the output folder. With dry_run the request is printed and nothing is sent."""
    import higgsfield_client  # lazy: only needed for this command

    out = product_dir / config.generated_dir_name(product_name)
    out.mkdir(parents=True, exist_ok=True)
    model = model or config.HIGGSFIELD_MODEL
    refs = refs or pick_references(product_dir / "competitor_imgs")
    if not refs:
        raise SystemExit(f"no reference images in {product_dir / 'competitor_imgs'}; run `grab` first")

    client = higgsfield_client.SyncClient(timeout=180.0)
    log_path = out / "generation_log.json"
    entries = json.loads(log_path.read_text()) if log_path.exists() else []
    existing = sum(1 for p in out.iterdir() if p.suffix.lower() in IMAGE_SUFFIXES)

    n = num_images or config.HIGGSFIELD_NUM_IMAGES
    per_call = profile_for(model)["per_call"]
    repeats = 1 if per_call is None else max(1, -(-n // per_call))   # ceil(n / per_call)
    if dry_run:
        print(json.dumps({"model": model, "references": [p.name for p in refs], "requests_per_prompt": repeats,
                          "arguments": build_arguments(prompts[0], ["<uploaded-url>"] * len(refs), num_images=num_images, model=model)}, indent=2))
        return out

    try:
        ref_urls = upload_references(client, refs)
    except Exception as e:  # noqa: BLE001
        raise SystemExit(explain_error(e, model)) from e
    jobs = [(p, k) for p in prompts for k in range(repeats)]
    for i, (prompt, k) in enumerate(jobs, 1):
        args = build_arguments(prompt, ref_urls, num_images=num_images, model=model)
        log.info("request %d/%d -> %s", i, len(jobs), model)
        started = time.time()
        try:
            result = client.subscribe(model, arguments=args)
        except Exception as e:  # noqa: BLE001 - one bad prompt must not lose the others
            log.error("generation failed for prompt %d: %s", i, explain_error(e, model))
            entries.append({"prompt": prompt, "model": model, "error": str(e), "at": datetime.now(timezone.utc).isoformat()})
            log_path.write_text(json.dumps(entries, indent=2))
            continue
        urls = result_image_urls(result)
        if not urls:
            log.warning("no image URLs in result for prompt %d: %s", i, json.dumps(result)[:500])
        saved = []
        for url in urls:
            existing += 1
            path = download(url, out / f"gen_{existing:02d}.jpg")
            saved.append(path.name)
            log.info("saved %s", path.name)
        entries.append({"prompt": prompt, "model": model, "references": [p.name for p in refs], "arguments": {k: v for k, v in args.items() if not isinstance(v, list)},
                        "result_urls": urls, "files": saved, "seconds": round(time.time() - started, 1),
                        "at": datetime.now(timezone.utc).isoformat()})
        log_path.write_text(json.dumps(entries, indent=2))
    return out


def check_credentials(sample: Path | None = None) -> str:
    """Upload one small image to Higgsfield and return its public URL. Proves HF_KEY works
    and that the network path is open, without spending generation credits."""
    import io

    import higgsfield_client

    client = higgsfield_client.SyncClient(timeout=60.0)
    if sample and sample.exists():
        import mimetypes
        return upload_bytes(client, sample.read_bytes(), mimetypes.guess_type(sample.name)[0] or "image/jpeg")
    # 1x1 PNG so the check needs no file on disk
    png = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000154a24f5d0000000049454e44ae426082")
    return upload_bytes(client, io.BytesIO(png).getvalue(), "image/png")


def _status_code(e: Exception) -> int | None:
    """HTTP status behind a HiggsfieldClientError (chained from httpx.HTTPStatusError)."""
    cause = e.__cause__
    resp = getattr(cause, "response", None)
    return getattr(resp, "status_code", None)


def explain_error(e: Exception, model: str) -> str:
    """Turn the SDK's errors into the next thing to try."""
    import httpx

    text = str(e)
    if isinstance(e, UploadError):
        return (f"{text}\nHiggsfield accepted the key (it issued the upload URL); the bucket then refused the upload. "
                "Run again with `python pdp.py -v hf-check` and send me the output, it names the headers the URL was signed for.")
    if isinstance(e, (httpx.TransportError, ConnectionError, OSError)):
        return (f"could not reach platform.higgsfield.ai ({type(e).__name__}: {text[:120]}). This is the network, not the key: "
                "check VPN / proxy / firewall, then retry.")
    if isinstance(e, KeyError):
        return f"unexpected response shape from Higgsfield (missing {text}); run with -v and share the log."
    code = _status_code(e)
    low = text.lower()
    if "credit" in low or "balance" in low or code == 402:
        return ("Higgsfield Cloud reports no API credits on this account (the API balance at cloud.higgsfield.ai is separate "
                "from the credits in the higgsfield.ai app). Top up under Billing on cloud.higgsfield.ai, then retry.")
    if code in (401, 403) or "unauthorized" in low or "invalid api key" in low:
        return (f"Higgsfield rejected the credentials (HTTP {code}: {text[:200]}). HF_KEY must be the API key *id* and *secret* "
                "from https://cloud.higgsfield.ai (Settings > API keys), joined with a colon, not a key from the higgsfield.ai "
                "consumer app. If the key is from cloud.higgsfield.ai, check the account has credits and the key was not revoked. "
                "Alternative: the CLI route (`higgsfield auth login`, then `python pdp.py hf-check --backend cli`).")
    if code == 404 or "not found" in low:
        return (f"model id '{model}' not found on platform.higgsfield.ai. Open the model's page on cloud.higgsfield.ai, copy the id from its "
                "API example, and set HIGGSFIELD_MODEL in .env (and HIGGSFIELD_IMAGE_ARG if its reference field is not 'image_urls').")
    if code in (400, 422) or "validation" in low:
        return (f"Higgsfield rejected the arguments for '{model}': {text[:300]}. Compare with the model's API example on cloud.higgsfield.ai; "
                "adjust HIGGSFIELD_IMAGE_ARG / HIGGSFIELD_ASPECT / HIGGSFIELD_RESOLUTION or drop fields with HIGGSFIELD_EXTRA_ARGS.")
    return text


# --------------------------------------------------------------------------- model discovery
CANDIDATE_MODELS = (
    # bytedance seedream family
    "bytedance/seedream/v4/text-to-image", "openai/gpt-image-2/edit", "bytedance/seedream/v4/image-to-image",
    "bytedance/seedream/v4/image-edit", "bytedance/seedream/v4.5/text-to-image", "bytedance/seedream/v4.5/edit",
    "bytedance/seedream/v4.5/image-to-image", "bytedance/seedream/v5/edit", "bytedance/seedream/v5/image-to-image",
    "bytedance/seedream/v5-lite/edit", "bytedance/seedream-4.5/edit", "bytedance/seedream-4.5/image-to-image",
    # google nano banana family
    "google/nano-banana/edit", "google/nano-banana/image-to-image", "google/nano-banana/text-to-image",
    "google/nano-banana-pro/edit", "google/nano-banana-pro/image-to-image", "google/nano-banana-2/edit",
    "google/nano-banana-2/image-to-image", "google/gemini-2.5-flash-image/edit", "google/gemini-3-pro-image/edit",
    # higgsfield soul
    "higgsfield-ai/soul/text-to-image", "higgsfield-ai/soul/image-to-image", "higgsfield-ai/soul/v2/text-to-image",
    "higgsfield-ai/soul/v2/image-to-image", "higgsfield-ai/soul-v2/image-to-image", "higgsfield-ai/dop/standard",
    # others commonly hosted
    "black-forest-labs/flux-kontext/max", "black-forest-labs/flux-kontext/pro", "bfl/flux-kontext-max",
    "black-forest-labs/flux-2/edit", "openai/gpt-image-1.5/edit", "openai/gpt-image-2/edit", "openai/gpt-image/edit",
    "reve/text-to-image", "reve/edit", "reve/image-to-image", "qwen/qwen-image/edit", "qwen/qwen-image-edit",
)


def probe_model(client, model: str) -> tuple[str, str]:
    """POST an empty body to a model endpoint. Returns (status, detail):
    'exists' with the validation message (which names the required fields) when the model is there,
    'missing' on 404, 'other' with the response text otherwise. Nothing is generated or charged."""
    from higgsfield_client.exceptions import HiggsfieldClientError

    try:
        resp = client._transport.request("POST", model, json={})
    except HiggsfieldClientError as e:
        code = _status_code(e)
        text = str(e)
        if code == 404 or "not found" in text.lower():
            return "missing", ""
        if code in (400, 422):
            return "exists", text[:600]
        return "other", f"HTTP {code}: {text[:300]}"
    except Exception as e:  # noqa: BLE001
        return "other", str(e)[:300]
    return "exists", f"accepted an empty request?! {resp.text[:200]}"


def required_fields(detail: str) -> list[str]:
    """Field names out of a FastAPI-style validation message like
    [{'loc': ['body', 'prompt'], 'msg': 'Field required'}, ...]."""
    import re
    names = re.findall(r"'loc':\s*\[\s*'body',\s*'([^']+)'", detail) or re.findall(r'"loc":\s*\[\s*"body",\s*"([^"]+)"', detail)
    return list(dict.fromkeys(names))


IMAGE_FIELD_CANDIDATES = ("image_urls", "image_url", "images", "image", "input_images", "reference_images",
                          "reference_image_urls", "reference_urls", "init_image", "init_images", "source_image")
OTHER_FIELD_CANDIDATES = ("aspect_ratio", "resolution", "num_images", "quality", "size", "seed", "strength", "style", "enhance_prompt")


_ENUM = re.compile(r"^(\w+): .*? is not one of \[(.*)\]", re.S)
_TYPE = re.compile(r"^(\w+): .*? is not of type '(\w+)'")
_REQ = re.compile(r"'(\w+)' is a required property")
_EXTRA = re.compile(r"Additional properties are not allowed \((.*?) (?:was|were) unexpected\)")
_LOC = re.compile(r"'loc':\s*\[\s*'body',\s*'(\w+)'.*?'msg':\s*'([^']*)'", re.S)
_TYPED_VALUE = {"string": "x", "integer": 1, "number": 1, "array": [], "boolean": True, "object": {}, "null": None}


def _enum_first(raw: str):
    import ast
    try:
        vals = ast.literal_eval("[" + raw + "]")
        return vals[0] if vals else "x"
    except (ValueError, SyntaxError):
        return raw.split(",")[0].strip().strip("'\"")


def map_fields(client, model: str, *, max_rounds: int = 40, log_fn=print) -> dict:
    """Discover a model's request schema by repeatedly sending an invalid request and fixing
    whatever the validator complains about. prompt stays invalid (a number) as the safety net
    until every other field is settled; the final valid request, if accepted, is cancelled at once.
    Returns {"known": {field: description}, "unknown": [candidates the model rejected], "log": [...]}."""
    from higgsfield_client.exceptions import HiggsfieldClientError

    body: dict = {"prompt": 123}
    body.update({k: 123 for k in IMAGE_FIELD_CANDIDATES})
    body.update({k: 123 for k in OTHER_FIELD_CANDIDATES})
    known: dict[str, str] = {}
    unknown: list[str] = []
    prompt_fixed = False
    for _ in range(max_rounds):
        try:
            resp = client._transport.request("POST", model, json=body)
        except HiggsfieldClientError as e:
            msg = str(e).strip()
        except Exception as e:  # noqa: BLE001
            log_fn(f"stopped: {e}")
            break
        else:
            try:
                rid = resp.json().get("request_id")
                if rid:
                    client.get_request_controller(rid).cancel()
                    log_fn(f"final request was accepted; cancelled {rid}")
            except Exception as e:  # noqa: BLE001
                log_fn(f"accepted but could not cancel: {e}")
            break
        log_fn(f"validator: {msg[:160]}")
        m = _EXTRA.search(msg)
        if m:
            for name in re.findall(r"'(\w+)'", m.group(1)):
                unknown.append(name)
                body.pop(name, None)
            continue
        m = _ENUM.search(msg)
        if m:
            field, raw = m.group(1), m.group(2)
            known[field] = f"one of [{raw}]"
            body[field] = _enum_first(raw)
            if field == "prompt":
                prompt_fixed = True
            continue
        m = _TYPE.search(msg)
        if m:
            field, typ = m.group(1), m.group(2)
            known[field] = typ
            body[field] = _TYPED_VALUE.get(typ, "x")
            if field == "prompt":
                prompt_fixed = True
            continue
        m = _REQ.search(msg)
        if m:
            known[m.group(1)] = known.get(m.group(1), "required")
            body[m.group(1)] = "x"
            continue
        m = re.search(r"^(\w+): .*should be non-empty", msg)
        if m:
            known[m.group(1)] = known.get(m.group(1), "array") + ", non-empty"
            log_fn("stopped: the only remaining complaint needs real data (a non-empty reference list); schema mapped far enough")
            break
        m = _LOC.search(msg)   # pydantic-style list of errors: fix the first
        if m:
            field, why = m.group(1), m.group(2)
            known[field] = why
            body[field] = [] if "list" in why or "array" in why else "x"
            if field == "prompt":
                prompt_fixed = True
            continue
        log_fn(f"stopped: unrecognised validator message")
        break
    if not prompt_fixed and "prompt" not in known:
        known["prompt"] = "required (never reached)"
    for k in list(body):
        if k not in known and k != "prompt" and k not in unknown:
            unknown.append(k)   # never complained about: with additionalProperties allowed these are simply ignored
    return {"known": known, "unknown": unknown}


def probe_fields(client, model: str) -> str:
    """Send a request that can never validate (prompt as a number) with candidate image/option
    fields also as numbers; the validator's answer names which fields the model knows.
    Nothing is generated or charged."""
    from higgsfield_client.exceptions import HiggsfieldClientError

    body = {"prompt": 123}
    body.update({k: 123 for k in IMAGE_FIELD_CANDIDATES})
    body.update({k: 123 for k in OTHER_FIELD_CANDIDATES})
    try:
        client._transport.request("POST", model, json=body)
    except HiggsfieldClientError as e:
        return f"HTTP {_status_code(e)}: {e}"
    except Exception as e:  # noqa: BLE001
        return f"error: {e}"
    return "accepted?! (unexpected: the probe should never validate)"
